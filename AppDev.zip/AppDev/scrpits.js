document.addEventListener('DOMContentLoaded', () => {
    const carImage = document.getElementById('car-image');
    const buttons = document.querySelectorAll('.option-btn');

    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const type = button.dataset.color || button.dataset.wheels || button.dataset.accessory;
            const category = button.dataset.color ? 'color' : button.dataset.wheels ? 'wheels' : 'accessory';

            updateCarImage(category, type);
        });
    });

    function updateCarImage(category, type) {
        let newSrc = 'car-default.png';
        
        if (category === 'color') {
            newSrc = `car-${type}.png`;
        } else if (category === 'wheels') {
            newSrc = `car-wheels-${type}.png`;
        } else if (category === 'accessory') {
            newSrc = `car-accessory-${type}.png`;
        }

        carImage.src = newSrc;
    }
});
