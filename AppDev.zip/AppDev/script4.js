// Get the live chat container and its elements
const liveChatContainer = document.getElementById('live-chat-container');
const liveChatHeader = document.getElementById('live-chat-header');
const liveChatCloseBtn = document.getElementById('live-chat-close-btn');
const liveChatMessages = document.getElementById('live-chat-messages');
const liveChatForm = document.getElementById('live-chat-form');
const liveChatInput = document.getElementById('live-chat-input');
const liveChatSendBtn = document.getElementById('live-chat-send-btn');

// Add event listeners
liveChatCloseBtn.addEventListener('click', () => {
  liveChatContainer.style.display = 'none';
});

liveChatSendBtn.addEventListener('click', (e) => {
  e.preventDefault();
  const message = liveChatInput.value.trim();
  if (message !== '') {
    // Append the message to the chat log
    appendMessageToChatLog(message, 'user');
    liveChatInput.value = '';
    // Simulate a response from the support team
    setTimeout(() => {
      // const response = `Hello! Thank you for reaching out to us. We'll get back to you soon.`;
      const response = `Hello! Thank you for reaching out to us. Tell me the problem.`;

      appendMessageToChatLog(response, 'support');
    }, 2000);
  }
});

// Function to append a message to the chat log
function appendMessageToChatLog(message, type) {
  const messageHTML = `
    <div class="chat-message ${type}">
      <p>${message}</p>
    </div>
  `;
  liveChatMessages.innerHTML += messageHTML;
  liveChatMessages.scrollTop = liveChatMessages.scrollHeight;
}

// Initialize the live chat
liveChatContainer.style.display = 'block';