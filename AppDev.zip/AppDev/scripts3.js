document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('maintenance-form');
    const taskList = document.getElementById('task-list');

    form.addEventListener('submit', (event) => {
        event.preventDefault();
        
        const taskInput = document.getElementById('task');
        const dateInput = document.getElementById('date');

        const task = taskInput.value;
        const date = dateInput.value;

        if (task && date) {
            const listItem = document.createElement('li');
            listItem.textContent = `${task} - Due by ${date}`;
            taskList.appendChild(listItem);

            taskInput.value = '';
            dateInput.value = '';
        }
    });
});

